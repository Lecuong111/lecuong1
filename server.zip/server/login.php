<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $email = $_POST['email'];
    $password = $_POST['password'];

    require_once 'connect.php';

    $sql = "SELECT * FROM users_table WHERE email= '$email'";
    $response = mysqli_query($conn, $sql);
    $resurt = array();
    $resurt['login'] = array();

    if (mysqli_num_rows($response) == 1){
        $row = mysqli_fetch_assoc($response);
        if (password_verify($password, $row['password'])){
            $resurt['login']['email'] = $row['email'];
            $resurt['login']['password'] = $row['password'];
            $resurt['success'] = "1";
            $resurt['message'] = "success";
            echo json_encode($resurt);
            return;
        }
        $resurt['success'] = "0";
        $resurt['message'] = "error";
    }else{
        $resurt['success'] = "0";
        $resurt['message'] = "error";
    }
    echo json_encode($resurt);

}
?>
